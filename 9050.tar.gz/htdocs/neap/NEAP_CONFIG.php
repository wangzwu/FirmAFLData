<?	
	$REBOOTTIME = 65;	
	$WAN1  = "WAN-1";
	$WAN2  = "WAN-2";
	$WLAN1 = "WLAN-1";
	$WLAN2 = "WLAN-2";
	$LAN1  = "LAN-1";
	$LAN2  = "LAN-2";
?>

