<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("To use this feature, you must first have a Dynamic DNS account from one of the providers in the drop down menu.");
?></p>
