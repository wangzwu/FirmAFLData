<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo "<strong>".i18n("DMZ").":</strong><br/>";
	echo i18n("Only enable the DMZ option as a last resort. If you are having trouble using an application from a computer behind the router, first try opening ports associated with the application in the Advanced Port Forwarding section.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo "<strong>".i18n("Firewall").":</strong><br/>";
	echo i18n("Firewall Rules are an advanced feature used to deny or allow traffic from passing through the device. You can create detailed rules for the device. Please refer to the manual for more details and examples.");
?></p>
