<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("An Active session is a conversation between a program or application on a LAN-side computer and a program or application on a WAN-side computer.");
?></p>
