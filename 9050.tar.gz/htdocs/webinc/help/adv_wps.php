<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n('<strong>Enable</strong> if other wireless devices you wish to include in the local network support Wi-Fi Protected Setup.');
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n('Only "Admin" account can change security settings.');
?></p>
<!--<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n('<strong>Lock Wireless Security Settings</strong> after all wireless network devices have been configured.');
?></p>-->
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n('Click <strong>Connect your Wireless Device</strong> to use Wi-Fi Protected Setup to add wireless devices to the wireless network.');
?></p>
