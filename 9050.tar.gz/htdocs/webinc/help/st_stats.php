<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("This is a summary displaying the number of packets that have passed between the Internet and the LAN since the router was last initialized.");
?></p>
