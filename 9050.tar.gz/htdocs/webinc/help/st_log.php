<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Click on the Save button to save log file to local hard drive which can later send to the network administrator for troubleshooting.");
	echo i18n("You can also select what type of event you would like to be logged from Log Type & Level.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("Check the log frequently to detect unauthorized network usage.");
?></p>
