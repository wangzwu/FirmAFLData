<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("All of your LAN, Internet and WIRELESS 802.11 N connection details are displayed here.");
?></p>
