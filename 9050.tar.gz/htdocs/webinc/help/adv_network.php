<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("For added security, it is recommended that you disable the <strong>WAN Ping Response</strong> option. Ping is often used by malicious Internet users to locate active networks or PCs.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("The WAN speed is usually detected automatically. If you are having problems connecting to the WAN, try selecting the speed manually.");
?></p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("If you are having trouble receiving video on demand type of service from the Internet, make sure the Multicast Stream option is enabled.");
?></p>
