<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
//	echo i18n("If the <strong>Measured Uplink Speed</strong> is known to be incorrect (that is, it produces suboptimal performance), disable <strong>Automatic Uplink Speed</strong> and enter the <strong>Manual Uplink Speed</strong>.").' ';
	echo i18n("Some experimentation and performance measurement may be required to converge on the optimal value.");
?></p>
