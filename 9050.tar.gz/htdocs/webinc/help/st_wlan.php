<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("This is a list of all wireless clients that are currently connected to your wireless router.");
?></p>
