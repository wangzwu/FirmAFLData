<strong><?echo i18n("Helpful Hints");?>...</strong>
<br/><br/>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("For each rule you can create a name and control the drection of traffic. You can also allow or deny a range of IP Addresses,the protocol and a port range.");?>
</p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo i18n("In order to apply a schedule to a Firewall rule,your must first define a schedule on the ").'<a href="/tools_sch.php">'.i18n("Tools -> Schedules ").'</a>'.i18n("page.");?>
</p>
<p>&nbsp;&#149;&nbsp;&nbsp;<?
	echo '<a href="/spt_adv.php#IPv6Firewall">'.i18n("More...").'</a>';
?></p>
