<module>
	<service>STARSPEED.WAN-1</service>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
</module>
