<? include "/htdocs/webinc/getcfg/RUNTIME.INF.BRIDGE-1.xml.php"; ?>
