<? include "/htdocs/webinc/getcfg/DDNS4.WAN-1.xml.php"; ?>
