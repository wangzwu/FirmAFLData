<module>
	<service>RUNTIME.UPNP.PORTM</service>
	<runtime>
		<upnpigd>
		<?echo dump(3, "/runtime/upnpigd");?>
		</upnpigd>
	</runtime>
	<ACTIVATE>ignore</ACTIVATE>
</module>
