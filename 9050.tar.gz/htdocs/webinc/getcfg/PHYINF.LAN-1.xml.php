<? include "/htdocs/webinc/getcfg/PHYINF.BRIDGE-1.xml.php"; ?>
