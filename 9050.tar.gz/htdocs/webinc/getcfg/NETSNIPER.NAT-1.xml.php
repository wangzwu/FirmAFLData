<module>
	<service>NETSNIPER.NAT-1</service>
	<nat>
<?		echo dump(2, "/nat");
?>	</nat>
</module>
