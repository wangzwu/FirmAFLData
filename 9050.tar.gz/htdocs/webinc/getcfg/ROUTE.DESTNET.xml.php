<module>
	<service><?=$GETCFG_SVC?></service>
	<route>
		<destination>
<?		echo dump(3, "/route/destination");
?>		</destination>
	</route>
</module>
