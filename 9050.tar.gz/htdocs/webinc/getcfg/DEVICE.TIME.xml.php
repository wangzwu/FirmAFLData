<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<time>
<?			echo dump(3, "/device/time");
?>		</time>
	</device>
</module>
