<? include "/htdocs/webinc/getcfg/WIFI.WLAN-1.xml.php"; ?>
