<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<hostname><?echo get("x", "/device/hostname");?></hostname>
	</device>
</module>
