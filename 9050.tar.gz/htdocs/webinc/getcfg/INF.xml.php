<module>
	<service><?=$GETCFG_SVC?></service>
<?		foreach ("/inf") echo "\t<inf>\n".dump(2, "/inf:".$InDeX)."\t</inf>\n";
?>	<ACTIVATE>ignore</ACTIVATE>
</module>
