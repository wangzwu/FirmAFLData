<module>
	<service><?=$GETCFG_SVC?></service>
	<route>
		<static>
<?		echo dump(3, "/route/static");
?>		</static>
	</route>
</module>
