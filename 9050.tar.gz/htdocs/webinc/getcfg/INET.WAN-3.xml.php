<? include "/htdocs/webinc/getcfg/INET.BRIDGE-1.xml.php"; ?>
