<module>
	<service>WAN.RESTART</service>
	<SETCFG>ignore</SETCFG>
</module>
