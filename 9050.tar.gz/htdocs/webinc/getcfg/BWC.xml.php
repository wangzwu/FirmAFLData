<module>
	<service>BWC</service>
	<bwc>
<?		echo dump(2, "/bwc");
?>	</bwc>
</module>
