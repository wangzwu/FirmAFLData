<module>
	<service>NAT</service>
	<nat>
<?		echo dump(2, "/nat");
?>	</nat>
</module>
