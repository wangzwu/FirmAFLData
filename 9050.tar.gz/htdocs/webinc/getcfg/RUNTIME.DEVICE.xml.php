<module>
	<service>RUNTIME.DEVICE</service>
	<runtime>
		<device>
<?			echo dump(3, "/runtime/device");
?>		</device>
		<devdata>
<?			echo dump(3, "/runtime/devdata");
?>		</devdata>
	
	</runtime>
	<SETCFG>ignore</SETCFG>
	<ACTIVATE>ignore</ACTIVATE>
</module>
