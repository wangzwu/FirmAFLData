<module>
	<service><?=$GETCFG_SVC?></service>
	<wifi>
<?      echo dump(2, "/wifi");
?>  </wifi>
</module>
