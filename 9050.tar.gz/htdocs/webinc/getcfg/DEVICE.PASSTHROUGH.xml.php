<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<passthrough>
<?			echo dump(3, "/device/passthrough");
?>		</passthrough>
	</device>
</module>
