<? include "/htdocs/webinc/getcfg/PFWD.NAT-1.xml.php"; ?>
