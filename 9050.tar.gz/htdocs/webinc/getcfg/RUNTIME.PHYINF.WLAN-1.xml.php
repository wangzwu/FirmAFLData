<? include "/htdocs/webinc/getcfg/RUNTIME.PHYINF.ETH-1.xml.php"; ?>
