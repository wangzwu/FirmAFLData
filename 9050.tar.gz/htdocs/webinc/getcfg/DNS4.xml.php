<module>
	<service><?=$GETCFG_SVC?></service>
	<dns4>
<?		echo dump(2, "/dns4");
?>	</dns4>
</module>
