<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<multicast>
<?			echo dump(3, "/device/multicast");
?>		</multicast>
	</device>
</module>
