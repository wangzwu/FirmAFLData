<? include "/htdocs/webinc/getcfg/DNS4.LAN-1.xml.php"; ?>
