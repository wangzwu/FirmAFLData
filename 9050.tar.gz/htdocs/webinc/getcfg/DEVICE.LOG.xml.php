<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<log>
<?			echo dump(3, "/device/log");
?>		</log>
	</device>
</module>
