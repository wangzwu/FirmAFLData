<module>
	<service><?=$GETCFG_SVC?></service>
	<inet>
<?		echo dump(2, "/inet");
?>	</inet>
	<ACTIVATE>ignore</ACTIVATE>
</module>
