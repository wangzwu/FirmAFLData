<module>
	<service>BRIDGE</service>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
</module>
