<module>
	<service><?=$GETCFG_SVC?></service>
	<route6>
		<static><? echo "\n".dump(3, "/route6/static");?>		</static>
	</route6>
</module>
