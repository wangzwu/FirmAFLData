<module>
	<service><?=$GETCFG_SVC?></service>
	<route>
		<ipunnumbered>
<?		echo dump(3, "/route/ipunnumbered");
?>		</ipunnumbered>
	</route>
</module>
