<module>
	<service><?=$GETCFG_SVC?></service>
	<device>
		<rdnss><?echo get("x","/device/rdnss");?></rdnss>
	</device>
</module>
