<? include "/htdocs/webinc/getcfg/DHCPS6.LAN-1.xml.php"; ?>
