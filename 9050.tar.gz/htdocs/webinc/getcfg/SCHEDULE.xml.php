<module>
	<service><?=$GETCFG_SVC?></service>
	<schedule>
<?echo dump(2, "/schedule");
?>	</schedule>
	<ACTIVATE>ignore</ACTIVATE>
</module>
