<module>
	<service>LAN</service>
	<FATLADY>ignore</FATLADY>
	<SETCFG>ignore</SETCFG>
</module>
