<?
$_GLOBALS["errorCode"]=200;
$_GLOBALS["SOAP_BODY"]="ACTION.GetNATRSIPStatus.php";
?>
