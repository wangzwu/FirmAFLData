HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "tools_sys_ulcfg";
$TEMP_MYGROUP   = "";
$TEMP_STYLE		= "simple";
include "/htdocs/webinc/templates.php";
?>
