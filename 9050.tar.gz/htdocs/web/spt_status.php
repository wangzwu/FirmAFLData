HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "spt_status";
$TEMP_MYGROUP   = "support";
$TEMP_STYLE		= "support";
include "/htdocs/webinc/templates.php";
?>
