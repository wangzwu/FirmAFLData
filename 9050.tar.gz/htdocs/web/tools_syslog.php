HTTP/1.1 200 OK

<?
include "/htdocs/phplib/inf.php";
$TEMP_MYNAME    = "tools_syslog";
$TEMP_MYGROUP   = "tools";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
