<?
include "/htdocs/web/adv_vsvr.php";
?>
